//
//  TabbarVC.swift
//  BiopleSwift
//
//  Created by Rhythmus on 29/06/18.
//  Copyright © 2018 Rhythmus. All rights reserved.
//

import UIKit

class TabbarVC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()


       UITabBar.appearance().tintColor = UIColor.white
        
        self.tabBar.itemPositioning = .centered
  
        UITabBar.appearance().backgroundImage = UIImage()
    
        UITabBar.appearance().backgroundColor = UIColor.init(red: 36/255, green: 41/255, blue:44/255 , alpha: 0.7)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
    
    }
    
}
