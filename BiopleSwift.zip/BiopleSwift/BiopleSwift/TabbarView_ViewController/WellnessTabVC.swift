//
//  WellnessTabVC.swift
//  BiopleSwift
//
//  Created by Rhythmus on 30/06/18.
//  Copyright © 2018 Rhythmus. All rights reserved.
//

import UIKit
import AVFoundation

class WellnessTabVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    let Cell_item_Arr: NSMutableArray = ["Electronic health record", "Personal information", "Family information", "Doctor details", "Consultant"]
    
    let ImgeCell: NSMutableArray = ["electronic-mac.png", "perosnal-infor.png", "family-info.png", "doctorc.png", "conmtantlt.png"]
    
    
    
    @IBOutlet var collectionViewC: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {

        return Cell_item_Arr.count
        
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        var cell: WellnessCCell? = collectionView.dequeueReusableCell(withReuseIdentifier: "WellnessCCell", for: indexPath) as? WellnessCCell
        if cell == nil {
            cell = WellnessCCell()
        }

        cell?.img_Cell?.image = UIImage.init(named: ImgeCell.object(at: indexPath.row) as! String)
        cell?.name_Cell?.text = Cell_item_Arr.object(at: indexPath.row) as? String
        return cell!
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        
        return CGSize(width: CGFloat((self.collectionViewC.bounds.size.width/2-8)), height: CGFloat(self.collectionViewC.bounds.size.width/2))
        
    }
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 2;
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAtIndex section: Int) -> CGFloat
    {
        return 2;
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSection section: Int) -> UIEdgeInsets
    {
        return UIEdgeInsetsMake(0, 5, 0, 5)
        
    }
    
 //   - (UIEdgeInsets)collectionView:
  //  (UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionA
    
    
    

}
