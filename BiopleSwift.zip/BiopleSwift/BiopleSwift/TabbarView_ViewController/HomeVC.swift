//
//  HomeVC.swift
//  BiopleSwift
//
//  Created by Rhythmus on 29/06/18.
//  Copyright © 2018 Rhythmus. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer
import ImageIO
class HomeVC: UIViewController,AVAudioPlayerDelegate,UIGestureRecognizerDelegate,UICollectionViewDelegate, UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource {
    var numRowCollectionArr = NSMutableArray()
    var player = AVAudioPlayer()
    var ringCollCellArr = NSMutableArray()
    var numRowtableArr = NSMutableArray()
    var  imageTableArr = NSMutableArray()


    @IBOutlet var homeCollectionView: UICollectionView!
   
    ////  navigationBar View
    
    @IBOutlet var viewNavigationMenuBar: UIView!
    
    @IBOutlet var viewSubNaviMenuBar: UIView!
   
    @IBOutlet var tableNaviMenuBar: UITableView!
    
    @IBOutlet var constHorizontelNaviMenubar: NSLayoutConstraint!
    
    @IBOutlet var btnSideMneuBar: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let cellSize = CGSize(width:homeCollectionView.frame.size.width , height:homeCollectionView.frame.size.height)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.minimumLineSpacing = 0.0
        layout.minimumInteritemSpacing = 0.0
        homeCollectionView.setCollectionViewLayout(layout, animated: true)
        
        
        let Nibname = UINib.init(nibName: "homeCollectionCell", bundle: nil)
        
        homeCollectionView.register(Nibname, forCellWithReuseIdentifier: "homeCollectionCell")
        
        numRowCollectionArr = ["SecondImage", "FirstImage"]
        
        numRowtableArr = ["Name","Email","Setting","Change password","Logout"]
        
        ringCollCellArr = ["raining","relax_tone","lightning","relaxed_piano","raining","relax_tone"]
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        tap.delegate = self
        view.addGestureRecognizer(tap)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        UIView.animate(withDuration: 0.5, delay: 0.0, options: [], animations:
            {
                self.constHorizontelNaviMenubar.constant = -self.view.frame.size.width*2
               
        }, completion: { (finished: Bool) in
            
        })
    }
    
    @objc public func handleTap(_ sender: UITapGestureRecognizer) {
        
        print("Hello World")
        UIView.animate(withDuration: 0.5, delay: 0.0, options: [], animations:
            {
                self.constHorizontelNaviMenubar.constant = -self.view.frame.size.width*2
        }, completion: { (finished: Bool) in
            
        })
        self.view .endEditing(true)
        
    }
    
    public func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool
    {
        if (touch.view?.isDescendant(of: self.tableNaviMenuBar))!
        {
            return false
        }else{
            return true}
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        player.play()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        player.pause()
    }

    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        
        
            return numRowCollectionArr.count
      
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        var cell: homeCollectionCell? = collectionView.dequeueReusableCell(withReuseIdentifier: "homeCollectionCell", for: indexPath) as? homeCollectionCell
        if cell == nil {
            cell = homeCollectionCell()
        }
        let imageData = NSData(contentsOf: Bundle.main.url(forResource: numRowCollectionArr.object(at: indexPath.row) as? String, withExtension: "gif")!)
        cell?.gifImageCell.image = UIImage.gifImageWithData(imageData! as Data)
        
        if indexPath.row == 0
        {
           
            let path = Bundle.main.path(forResource: ringCollCellArr.object(at: indexPath.row) as? String, ofType:"mp3")!
            let url = URL(fileURLWithPath: path)
            
            do {
                let sound = try AVAudioPlayer(contentsOf: url)
                player = sound
                player.numberOfLoops = -1
                player.prepareToPlay()
                player.play()
            } catch {
                print("error loading file")
                // couldn't load file :(
            }
        }
        
        
        
        return cell!
    }
    
  
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        
        return CGSize(width: CGFloat((self.homeCollectionView.bounds.size.width)), height: CGFloat(self.homeCollectionView.bounds.size.height))
        
    }
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 0;
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAtIndex section: Int) -> CGFloat
    {
        return 0.0;
    }
    
    @IBAction func clickedSideMenuBar(_ sender: UIButton)
    {
        UIView.animate(withDuration: 0.3, delay: 0.5, options: [], animations:
            {
                self.constHorizontelNaviMenubar.constant = 0
                
        }, completion: { (finished: Bool) in
            
        })
        
    }
    
    //////////////////////////////////////////////     Navigation Menu Bar tableview Delegate Method
    public func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
       
                return self.numRowtableArr.count
       
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
        
    {
        
       
            var cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! homeNaviMenuBarTableCell?
            if cell == nil
            {
                let Xib = Bundle.main.loadNibNamed("homeNaviMenuBarTableCell", owner: self, options: nil)! as NSArray
                cell = Xib[0] as? homeNaviMenuBarTableCell
                
//                let bgColorView = UIView()
//                bgColorView.backgroundColor = UIColor(red:0.96, green:0.45, blue:0.45, alpha:0.3)
//                cell?.selectedBackgroundView = bgColorView
                
                cell?.lblTableCellName?.font = UIFont.boldSystemFont(ofSize: 16)
                
            }
            
            cell?.lblTableCellName?.text = numRowtableArr.object(at: indexPath.row) as? String
         //   cell?.imgTableCell.image = UIImage.init(named: imageTableArr .object(at: indexPath.row) as! String)
            return cell!
        
    }
        public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
        {
            print("Sucesss")
            
            if tableView == self.tableNaviMenuBar
            {
            }
            
            
            
        }
        public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
        {
            let sized = view.bounds.size.width
            if tableView == tableNaviMenuBar
            {
                if sized >= 768
                {
                    return 90
                }else if sized >= 834
                {
                    return 100
                }else if sized >= 1024
                {
                    return 100
                }else if sized >= 320 || sized >= 414 || sized >= 812 || sized >= 667
                {
                    return 80
                }else
                {
                    return 50
                }
                
            }else{
                
                if sized >= 768
                {
                    return 230
                }else if sized >= 834
                {
                    return 156
                }else if sized >= 1024
                {
                    return 156
                }else if sized >= 320 || sized >= 414 || sized >= 812 || sized >= 667
                {
                    return 125
                }else
                {
                    return 130
                }
            }
        }
    
    
    
    
    
    
    
}
