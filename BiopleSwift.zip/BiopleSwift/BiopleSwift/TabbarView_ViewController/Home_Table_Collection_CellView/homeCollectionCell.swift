//
//  homeCollectionCell.swift
//  BiopleSwift
//
//  Created by Rhythmus on 29/06/18.
//  Copyright © 2018 Rhythmus. All rights reserved.
//

import UIKit

class homeCollectionCell: UICollectionViewCell{
    
    
    @IBOutlet var gifImageCell: UIImageView!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
        
        
       
    }

}






