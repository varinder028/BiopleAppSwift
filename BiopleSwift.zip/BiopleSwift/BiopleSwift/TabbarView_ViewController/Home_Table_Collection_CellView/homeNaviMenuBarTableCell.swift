//
//  homeNaviMenuBarTableCell.swift
//  BiopleSwift
//
//  Created by Rhythmus on 29/06/18.
//  Copyright © 2018 Rhythmus. All rights reserved.
//

import UIKit

class homeNaviMenuBarTableCell: UITableViewCell {

    @IBOutlet var lblTableCellName: UILabel!
    
    @IBOutlet var imgTableCell: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
