//
//  dashboardTabVC.swift
//  BiopleSwift
//
//  Created by Rhythmus on 30/06/18.
//  Copyright © 2018 Rhythmus. All rights reserved.
//

import UIKit


class dashboardTabVC: UIViewController{

   
    override func viewDidLoad() {
 
        super.viewDidLoad()

       
     
       
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
   
    
    
    

}
