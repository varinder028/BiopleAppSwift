//
//  WellnessCCell.swift
//  BiopleSwift
//
//  Created by Rhythmus on 05/07/18.
//  Copyright © 2018 Rhythmus. All rights reserved.
//

import UIKit

class WellnessCCell: UICollectionViewCell {

    
    @IBOutlet var img_Cell: UIImageView!
    
    @IBOutlet var name_Cell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
